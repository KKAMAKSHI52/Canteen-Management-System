const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database setup
const db = new sqlite3.Database('./canteen.db', (err) => {
  if (err) {
    console.error('Error opening database:', err.message);
  } else {
    console.log('Connected to SQLite database.');
    initializeDatabase();
  }
});

// Initialize database tables
function initializeDatabase() {
  db.serialize(() => {
    // Create selections table
    db.run(`
      CREATE TABLE IF NOT EXISTS selections (
        id TEXT PRIMARY KEY,
        employee_id TEXT NOT NULL,
        employee_name TEXT NOT NULL,
        date TEXT NOT NULL,
        breakfast BOOLEAN DEFAULT 0,
        lunch BOOLEAN DEFAULT 0,
        snacks BOOLEAN DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    `);

    // Create config table
    db.run(`
      CREATE TABLE IF NOT EXISTS config (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    `);

    // Insert default config if not exists
    const defaultConfig = {
      app_title: "Karmic Canteen Manager",
      company_name: "Karmic Solutions",
      breakfast_menu: "Idli, Dosa, Upma, Poha",
      lunch_menu: "Rice, Chapati, Dal, Vegetables, Curd",
      snacks_menu: "Tea, Coffee, Samosa, Biscuits",
      cutoff_time: "9:00 PM",
      background_color: "#f0f9ff",
      surface_color: "#ffffff",
      text_color: "#1e293b",
      primary_action_color: "#0ea5e9",
      secondary_action_color: "#64748b",
      font_family: "system-ui, -apple-system, sans-serif",
      font_size: 16
    };

    Object.entries(defaultConfig).forEach(([key, value]) => {
      db.run(`
        INSERT OR IGNORE INTO config (key, value) VALUES (?, ?)
      `, [key, JSON.stringify(value)]);
    });
  });
}

// API Routes

// Get all selections
app.get('/api/selections', (req, res) => {
  db.all('SELECT * FROM selections ORDER BY created_at DESC', [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(rows);
  });
});

// Create new selection
app.post('/api/selections', (req, res) => {
  const { id, employee_id, employee_name, date, breakfast, lunch, snacks, created_at, updated_at } = req.body;

  db.run(`
    INSERT INTO selections (id, employee_id, employee_name, date, breakfast, lunch, snacks, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [id, employee_id, employee_name, date, breakfast ? 1 : 0, lunch ? 1 : 0, snacks ? 1 : 0, created_at, updated_at], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ id: id, isOk: true });
  });
});

// Update selection
app.put('/api/selections/:id', (req, res) => {
  const { breakfast, lunch, snacks, updated_at } = req.body;
  const { id } = req.params;

  db.run(`
    UPDATE selections SET breakfast = ?, lunch = ?, snacks = ?, updated_at = ? WHERE id = ?
  `, [breakfast ? 1 : 0, lunch ? 1 : 0, snacks ? 1 : 0, updated_at, id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'Selection not found' });
    }
    res.json({ id: id, isOk: true });
  });
});

// Get config
app.get('/api/config', (req, res) => {
  db.all('SELECT * FROM config', [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    const config = {};
    rows.forEach(row => {
      config[row.key] = JSON.parse(row.value);
    });
    res.json(config);
  });
});

// Update config
app.post('/api/config', (req, res) => {
  const config = req.body;

  const stmt = db.prepare('INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)');

  Object.entries(config).forEach(([key, value]) => {
    stmt.run(key, JSON.stringify(value));
  });

  stmt.finalize((err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ isOk: true });
  });
});

// Serve frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'front.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  db.close((err) => {
    if (err) {
      console.error('Error closing database:', err.message);
    } else {
      console.log('Database connection closed.');
    }
    process.exit(0);
  });
});
