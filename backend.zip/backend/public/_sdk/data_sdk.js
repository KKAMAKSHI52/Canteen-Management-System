// Data SDK for handling meal selections
window.dataSdk = {
  init: function(dataHandler) {
    this.dataHandler = dataHandler;
    this.loadData();
    return { isOk: true };
  },

  loadData: async function() {
    try {
      const response = await fetch('/api/selections');
      if (response.ok) {
        const data = await response.json();
        this.dataHandler.onDataChanged(data);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  },

  create: async function(item) {
    try {
      const response = await fetch('/api/selections', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(item),
      });

      if (response.ok) {
        await this.loadData();
        return { isOk: true };
      } else {
        console.error('Failed to create item');
        return { isOk: false };
      }
    } catch (error) {
      console.error('Error creating item:', error);
      return { isOk: false };
    }
  },

  update: async function(item) {
    try {
      const response = await fetch(`/api/selections/${item.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(item),
      });

      if (response.ok) {
        await this.loadData();
        return { isOk: true };
      } else {
        console.error('Failed to update item');
        return { isOk: false };
      }
    } catch (error) {
      console.error('Error updating item:', error);
      return { isOk: false };
    }
  },

  delete: async function(id) {
    try {
      const response = await fetch(`/api/selections/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        await this.loadData();
        return { isOk: true };
      } else {
        console.error('Failed to delete item');
        return { isOk: false };
      }
    } catch (error) {
      console.error('Error deleting item:', error);
      return { isOk: false };
    }
  }
};
