// Element SDK for configuration management
window.elementSdk = {
  config: {},

  init: function(options) {
    this.defaultConfig = options.defaultConfig;
    this.onConfigChange = options.onConfigChange;
    this.mapToCapabilities = options.mapToCapabilities;
    this.mapToEditPanelValues = options.mapToEditPanelValues;
    this.loadConfig();
    return { isOk: true };
  },

  loadConfig: async function() {
    try {
      const response = await fetch('/api/config');
      if (response.ok) {
        this.config = await response.json();
        if (this.onConfigChange) {
          this.onConfigChange(this.config);
        }
      } else {
        this.config = { ...this.defaultConfig };
      }
    } catch (error) {
      console.error('Error loading config:', error);
      this.config = { ...this.defaultConfig };
    }
  },

  setConfig: async function(newConfig) {
    try {
      Object.assign(this.config, newConfig);
      const response = await fetch('/api/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newConfig),
      });

      if (response.ok) {
        if (this.onConfigChange) {
          this.onConfigChange(this.config);
        }
        return { isOk: true };
      } else {
        console.error('Failed to save config');
        return { isOk: false };
      }
    } catch (error) {
      console.error('Error saving config:', error);
      return { isOk: false };
    }
  },

  getCapabilities: function() {
    return this.mapToCapabilities ? this.mapToCapabilities(this.config) : {};
  },

  getEditPanelValues: function() {
    return this.mapToEditPanelValues ? this.mapToEditPanelValues(this.config) : new Map();
  }
};
