# Karmic Canteen Manager Backend

A Node.js/Express backend for the Karmic Canteen Manager application.

## Features

- SQLite database for data persistence
- RESTful API for meal selections and configuration
- Static file serving for frontend and SDK files
- CORS enabled for cross-origin requests

## Installation

1. Navigate to the backend directory:
   ```bash
   cd CANTEEN/backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Running the Application

Start the server:
```bash
npm start
```

The server will run on http://localhost:3000

## API Endpoints

### Selections
- `GET /api/selections` - Get all meal selections
- `POST /api/selections` - Create a new meal selection
- `PUT /api/selections/:id` - Update a meal selection

### Configuration
- `GET /api/config` - Get application configuration
- `POST /api/config` - Update application configuration

## Database

The application uses SQLite with the following tables:

- `selections`: Stores employee meal selections
- `config`: Stores application configuration

The database file `canteen.db` will be created automatically when the server starts.

## Project Structure

```
backend/
├── server.js          # Main server file
├── package.json       # Dependencies and scripts
├── canteen.db         # SQLite database (created automatically)
├── public/            # Static files
│   ├── front.html     # Frontend HTML
│   └── _sdk/          # SDK files
│       ├── data_sdk.js
│       └── element_sdk.js
└── README.md          # This file
